package com.seleniumtraining.utilities;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.lang.reflect.Method;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.DataProvider;

import com.seleniumtraining.base.Page;

public class TestUtilities extends Page {

	public static String screenshotPath;

	public static void captureScreenshot() {
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Date d = new Date();
		screenshotPath = System.getProperty("user.dir") + "\\Screenshots\\"
				+ d.toString().replace(":", "_").replace(" ", "_") + ".jpg";

		try {
			FileHandler.copy(srcFile, new File(screenshotPath));
			log.info("Screenshot Captured!! ");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Common Data provider function's code

	@DataProvider(name = "dp")
	public Object[][] getData(Method m) {
		log.info("Data Provider Method is called!! ");
		String sheetName = m.getName();
		int row = excel.rowCount(sheetName);
		int col = excel.colCount(sheetName);

		Object[][] data = new Object[row - 1][1];
		Hashtable<String, String> table = null;

		for (int i = 1; i < row; i++) {
			table = new Hashtable<String, String>();
			for (int j = 0; j < col; j++) {
				table.put(excel.getStringData(sheetName, 0, j), excel.getStringData(sheetName, i, j));
			}
			data[i - 1][0] = table;
		}
		log.info("Exiting Data Provider method");
		return data;

	}

	// Returns a boolean value to check if the test is runnable
	public static boolean isTestRunnable(String testName, ReadExcelUtility excel) {

		log.info("Checking if the test: " + testName + " is runnable?");
		String sheetName = config.getProperty("testCaseRunModeSheet");
		int rows = excel.rowCount(sheetName);

		for (int rNum = 1; rNum < rows; rNum++) {
			String testCase = excel.getStringData(sheetName, "testID", rNum);
			if (testCase.equalsIgnoreCase(testName)) {

				String runmode = excel.getStringData(sheetName, "runMode", rNum);

				if (runmode.equalsIgnoreCase("Y")) {
					log.info("The test: " + testName + " is runnable.");
					return true;
				} else {
					log.info("The test: " + testName + " is not runnable.");
					return false;
				}

			}

		}
		log.info("The test: " + testName + " Loop not working.");
		return false;

	}
}
