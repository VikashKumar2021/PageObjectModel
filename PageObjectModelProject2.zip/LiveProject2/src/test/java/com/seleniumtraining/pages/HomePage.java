package com.seleniumtraining.pages;

import com.seleniumtraining.base.Page;

public class HomePage extends Page {

		
	public void gotoCustomerLogin() {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is called.");
		click("customerLoginLoginButtom_CSS");
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is exited.");
	}
	
	public BankManagerPage gotoBankManagerLogin() {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is called.");
		log.debug("Inside the  method: " +new Throwable().getStackTrace()[0].getMethodName());
		click("bankManagerLoginButtom_CSS");
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is exited.");
		return new BankManagerPage();
	}
	
	public void homePageNavigateBack() {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is called.");
		click("homePageTab_CSS");
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is exited.");
	}
}
