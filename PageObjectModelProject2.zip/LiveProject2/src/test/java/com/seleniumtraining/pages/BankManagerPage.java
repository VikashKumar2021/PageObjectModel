package com.seleniumtraining.pages;

import java.util.Hashtable;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.seleniumtraining.base.Page;

public class BankManagerPage extends Page {

	public String addCustomer(Hashtable<String, String> data) {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is called.");
		click("addCutomerTab_CSS");
		type("firstName_CSS", data.get("firstName"));
		type("lastName_CSS", data.get("lastName"));
		type("postCode_CSS", data.get("postCode"));
		click("addCustomerSubmitButton_CSS");
		log.debug("Sbumitting the form!!");
		// Alert alert= driver.switchTo().alert();
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		String successMessage = alert.getText();
		alert.accept();
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is exited.");
		return successMessage;
	}

	public String openAccount(Hashtable<String, String> data) {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is called.");
		log.debug("Inside the test method: " + new Throwable().getStackTrace()[0].getMethodName());
		click("openAccountTab_XPATH");
		select("customerDropdown_ID", data.get("customerName"));
		select("currencyDropdown_ID", data.get("currency"));
		click("processButton_XPATH");
		log.debug("Sbumitting the form!!");
		// Alert alert= driver.switchTo().alert();
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		String successMessage = alert.getText();
		alert.accept();
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName()+ " is exited.");
		return successMessage;
	}

}
