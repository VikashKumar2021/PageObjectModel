package com.seleniumtraining.rough;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.seleniumtraining.pages.BankManagerPage;
import com.seleniumtraining.pages.HomePage;

public class BankManagerLoginTest {

	public static void main(String[] args) {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\" + "chromedriver.exe");
		
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://www.way2automation.com/angularjs-protractor/banking/#/login");
		HomePage homePage= new HomePage();
		BankManagerPage bnkMgrPage=homePage.gotoBankManagerLogin();
		

	}

}
